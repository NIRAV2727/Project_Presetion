-- ============================================================
-- QuizHub Platform - Database Setup Script for phpMyAdmin / MySQL
-- Database Name: quiz_db
-- Compatibility: MySQL 5.7+, MySQL 8.0+, MariaDB (phpMyAdmin)
-- ============================================================

CREATE DATABASE IF NOT EXISTS `quiz_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `quiz_db`;

-- ------------------------------------------------------------
-- 1. Table structure for `students`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `roll_no` VARCHAR(50) NOT NULL UNIQUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 2. Table structure for `quizzes`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `quizzes`;
CREATE TABLE `quizzes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(150) NOT NULL UNIQUE,
  `subject` VARCHAR(100) NOT NULL,
  `time_limit` INT NOT NULL DEFAULT 10 COMMENT 'Time limit in minutes',
  `difficulty` ENUM('Easy', 'Medium', 'Hard') NOT NULL DEFAULT 'Easy',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 3. Table structure for `questions`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `quiz_title` VARCHAR(150) NOT NULL,
  `question_text` TEXT NOT NULL,
  `option_a` VARCHAR(255) NOT NULL,
  `option_b` VARCHAR(255) NOT NULL,
  `option_c` VARCHAR(255) NOT NULL,
  `option_d` VARCHAR(255) NOT NULL,
  `correct_option` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`quiz_title`) REFERENCES `quizzes`(`title`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 4. Table structure for `results`
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `results`;
CREATE TABLE `results` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `student_name` VARCHAR(100) NOT NULL,
  `roll_no` VARCHAR(50) NOT NULL,
  `quiz_name` VARCHAR(150) NOT NULL,
  `score` VARCHAR(20) NOT NULL,
  `percentage` VARCHAR(20) NOT NULL,
  `grade` VARCHAR(10) NOT NULL,
  `attempt_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- SEED DATA INSERTS
-- ============================================================

-- Seed Students
INSERT INTO `students` (`name`, `email`, `password`, `roll_no`) VALUES
('Alex Johnson', 'alex@example.com', 'student123', 'STU-1001'),
('Sophia Smith', 'sophia@example.com', 'student123', 'STU-1002'),
('Michael Brown', 'student@gmail.com', 'student123', 'STU-1003'),
('Emily Davis', 'emily@example.com', 'student123', 'STU-1004');

-- Seed Quizzes
INSERT INTO `quizzes` (`title`, `subject`, `time_limit`, `difficulty`) VALUES
('Java Fundamentals', 'Programming', 10, 'Easy'),
('Database Systems', 'Computer Science', 15, 'Medium'),
('Web Development Essentials', 'Web Engineering', 12, 'Medium'),
('General Science & Tech', 'General Knowledge', 8, 'Easy');

-- Seed Questions for Java Fundamentals
INSERT INTO `questions` (`quiz_title`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`) VALUES
('Java Fundamentals', 'Which of the following is NOT a Java primitive type?', 'int', 'boolean', 'String', 'double', 'String'),
('Java Fundamentals', 'What is the default value of a boolean variable in Java?', 'true', 'false', '0', 'null', 'false'),
('Java Fundamentals', 'Which keyword is used to define a constant variable in Java?', 'const', 'static', 'final', 'immutable', 'final'),
('Java Fundamentals', 'Which concept of OOP allows a class to inherit properties from another class?', 'Polymorphism', 'Encapsulation', 'Inheritance', 'Abstraction', 'Inheritance'),
('Java Fundamentals', 'Which method is the main entry point of any standalone Java application?', 'start()', 'main()', 'init()', 'run()', 'main()');

-- Seed Questions for Database Systems
INSERT INTO `questions` (`quiz_title`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`) VALUES
('Database Systems', 'What does SQL stand for?', 'Structured Query Language', 'Sequential Query Language', 'Simple Query Logic', 'System Query Language', 'Structured Query Language'),
('Database Systems', 'Which SQL clause is used to filter records in a SELECT query?', 'GROUP BY', 'WHERE', 'ORDER BY', 'HAVING', 'WHERE'),
('Database Systems', 'Which SQL command is used to remove a table and all its data permanently?', 'REMOVE TABLE', 'DELETE TABLE', 'DROP TABLE', 'TRUNCATE TABLE', 'DROP TABLE'),
('Database Systems', 'What type of key uniquely identifies each row in a database table?', 'Foreign Key', 'Primary Key', 'Super Key', 'Candidate Key', 'Primary Key'),
('Database Systems', 'Which operator is used to search for a specified pattern in a column?', 'LIKE', 'MATCH', 'SEARCH', 'IN', 'LIKE');

-- Seed Questions for Web Development Essentials
INSERT INTO `questions` (`quiz_title`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`) VALUES
('Web Development Essentials', 'What does HTML stand for?', 'Hyper Text Markup Language', 'High Tech Modern Language', 'Hyper Transfer Main Language', 'Home Tool Markup Language', 'Hyper Text Markup Language'),
('Web Development Essentials', 'Which CSS property is used to change the background color of an element?', 'color', 'background-color', 'bgcolor', 'canvas-color', 'background-color'),
('Web Development Essentials', 'Which JavaScript array method adds an element to the end of an array?', 'push()', 'pop()', 'shift()', 'append()', 'push()'),
('Web Development Essentials', 'What is the default layout display mode of a <div> tag in HTML?', 'inline', 'block', 'flex', 'grid', 'block'),
('Web Development Essentials', 'Which HTTP status code signifies "200 OK"?', '404', '500', '200', '301', '200');

-- Seed Questions for General Science & Tech
INSERT INTO `questions` (`quiz_title`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`) VALUES
('General Science & Tech', 'What is the chemical symbol for Gold?', 'Au', 'Ag', 'Fe', 'Pb', 'Au'),
('General Science & Tech', 'Which planet in our solar system is known as the Red Planet?', 'Earth', 'Mars', 'Jupiter', 'Venus', 'Mars'),
('General Science & Tech', 'What is the speed of light in vacuum approximately?', '300,000 km/s', '150,000 km/s', '1,000,000 km/s', '30,000 km/s', '300,000 km/s'),
('General Science & Tech', 'Which component is considered the brain of a computer?', 'RAM', 'Hard Drive', 'CPU', 'GPU', 'CPU');

-- Seed Sample Results
INSERT INTO `results` (`student_name`, `roll_no`, `quiz_name`, `score`, `percentage`, `grade`) VALUES
('Alex Johnson', 'STU-1001', 'Java Fundamentals', '5/5', '100.0%', 'A+'),
('Sophia Smith', 'STU-1002', 'Database Systems', '4/5', '80.0%', 'A'),
('Michael Brown', 'STU-1003', 'Java Fundamentals', '4/5', '80.0%', 'A'),
('Emily Davis', 'STU-1004', 'Web Development Essentials', '3/5', '60.0%', 'B');
