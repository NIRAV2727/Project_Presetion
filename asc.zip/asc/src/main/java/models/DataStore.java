package models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import constants.DBConnection;

/**
 * DataStore - Core Data Management Layer for QuizHub Platform
 */
public class DataStore {

    public static List<Student>      students  = new ArrayList<>();
    public static List<Quiz>         quizzes   = new ArrayList<>();
    public static List<Question>     questions = new ArrayList<>();
    public static List<ResultRecord> results   = new ArrayList<>();

    public static Student currentStudent = null;
    public static Quiz    selectedQuiz   = null;
    public static int     lastScore      = 0;
    public static int     lastTotal      = 0;
    
    static {
        loadStudents();
        loadQuizzes();
        loadQuestions();
        loadResults();
    }
    
    public static void loadStudents() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT name, email, password, roll_no FROM students");
             ResultSet rs = stmt.executeQuery()) {

            List<Student> dbStudents = new ArrayList<>();
            while (rs.next()) {
                dbStudents.add(new Student(
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("password"),
                        rs.getString("roll_no")
                ));
            }
            students = dbStudents;
        } catch (SQLException e) {
            System.err.println("Failed to load students from DB: " + e.getMessage());
        }
        
        // Ensure default seed students are present
        ensureSeedStudents();
    }

    private static void ensureSeedStudents() {
        Student[] defaults = new Student[]{
            new Student("Alex Johnson", "alex@example.com", "student123", "STU-1001"),
            new Student("Sophia Smith", "sophia@example.com", "student123", "STU-1002"),
            new Student("Michael Brown", "student@gmail.com", "student123", "STU-1003"),
            new Student("Emily Davis", "emily@example.com", "student123", "STU-1004")
        };
        for (Student s : defaults) {
            boolean exists = false;
            for (Student existing : students) {
                if (existing.getEmail().equalsIgnoreCase(s.getEmail())) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement("INSERT INTO students (name, email, password, roll_no) VALUES (?,?,?,?)")) {
                    ps.setString(1, s.getName());
                    ps.setString(2, s.getEmail());
                    ps.setString(3, s.getPassword());
                    ps.setString(4, s.getRollNo());
                    ps.executeUpdate();
                    students.add(s);
                } catch (Exception ignored) {}
            }
        }
    }
    
    public static boolean addStudent(Student s) {
        String sql = "INSERT INTO students (name, email, password, roll_no) VALUES (?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getName()); 
            ps.setString(2, s.getEmail());
            ps.setString(3, s.getPassword());
            ps.setString(4, s.getRollNo());
            int rows = ps.executeUpdate();
            if (rows > 0) {
                boolean alreadyInList = false;
                for (Student existing : students) {
                    if (existing.getEmail().equalsIgnoreCase(s.getEmail()) ||
                        existing.getRollNo().equalsIgnoreCase(s.getRollNo())) {
                        alreadyInList = true;
                        break;
                    }
                }
                if (!alreadyInList) {
                    students.add(s);
                }
                return true;
            }
            return false;
        } catch (SQLException e) {
            System.err.println("addStudent error: " + e.getMessage());
            return false;
        }
    }
    
    public static boolean deleteStudent(Student s) {
        String sql = "DELETE FROM students WHERE roll_no=? OR email=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getRollNo());
            ps.setString(2, s.getEmail());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("deleteStudent error: " + e.getMessage());
        }
        students.remove(s);
        return true;
    }

    public static void loadQuizzes() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT title, subject, time_limit, difficulty FROM quizzes");
             ResultSet rs = stmt.executeQuery()) {
            List<Quiz> dbQuizzes = new ArrayList<>();
            while (rs.next()) {
                dbQuizzes.add(new Quiz(
                        rs.getString("title"),
                        rs.getString("subject"),
                        rs.getInt("time_limit"),
                        rs.getString("difficulty")
                ));
            }
            if (!dbQuizzes.isEmpty()) {
                quizzes = dbQuizzes;
            }
        } catch (Exception e) {
            System.err.println("DB loadQuizzes error: " + e.getMessage());
        }
        
        ensureSeedQuizzes();
    }

    private static void ensureSeedQuizzes() {
        Quiz[] defaults = new Quiz[]{
            new Quiz("Java Fundamentals", "Programming", 10, "Easy"),
            new Quiz("Database Systems", "Computer Science", 15, "Medium"),
            new Quiz("Web Development Essentials", "Web Engineering", 12, "Medium"),
            new Quiz("General Science & Tech", "General Knowledge", 8, "Easy")
        };
        for (Quiz q : defaults) {
            boolean exists = false;
            for (Quiz existing : quizzes) {
                if (existing.getTitle().equalsIgnoreCase(q.getTitle())) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                quizzes.add(q);
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement("INSERT INTO quizzes (title, subject, time_limit, difficulty) VALUES (?,?,?,?)")) {
                    ps.setString(1, q.getTitle());
                    ps.setString(2, q.getSubject());
                    ps.setInt(3, q.getTimeLimit());
                    ps.setString(4, q.getDifficulty());
                    ps.executeUpdate();
                } catch (Exception ignored) {}
            }
        }
    }
    
    public static boolean addQuiz(Quiz q) {
        if (q == null || q.getTitle() == null || q.getTitle().trim().isEmpty()) {
            return false;
        }
        String sql = "INSERT INTO quizzes (title, subject, time_limit, difficulty) VALUES (?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, q.getTitle());
            ps.setString(2, q.getSubject());
            ps.setInt(3, q.getTimeLimit());
            ps.setString(4, q.getDifficulty());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("addQuiz error: " + e.getMessage());
        }
        quizzes.add(q);
        return true;
    }
    
    public static void deleteQuiz(Quiz q) {
        String sql = "DELETE FROM quizzes WHERE title=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, q.getTitle());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("deleteQuiz error: " + e.getMessage());
        }
        quizzes.remove(q);
    }
    
    public static void loadQuestions() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT quiz_title, question_text, option_a, option_b, option_c, option_d, correct_option FROM questions");
             ResultSet rs = stmt.executeQuery()) {
            List<Question> dbQuestions = new ArrayList<>();
            while (rs.next()) {
                dbQuestions.add(new Question(
                        rs.getString("quiz_title"),
                        rs.getString("question_text"),
                        rs.getString("option_a"),
                        rs.getString("option_b"),
                        rs.getString("option_c"),
                        rs.getString("option_d"),
                        rs.getString("correct_option")
                ));
            }
            if (!dbQuestions.isEmpty()) {
                questions = dbQuestions;
            }
        } catch (Exception e) {
            System.err.println("DB loadQuestions error: " + e.getMessage());
        }
        
        ensureSeedQuestions();
    }

    private static void ensureSeedQuestions() {
        Question[] defaults = new Question[]{
            // Java Fundamentals
//            new Question("Java Fundamentals", "Which of the following is NOT a Java primitive type?", "int", "boolean", "String", "double", "String"),
//            new Question("Java Fundamentals", "What is the default value of a boolean variable in Java?", "true", "false", "0", "null", "false"),
//            new Question("Java Fundamentals", "Which keyword is used to define a constant variable in Java?", "const", "static", "final", "immutable", "final"),
//            new Question("Java Fundamentals", "Which concept of OOP allows a class to inherit properties from another class?", "Polymorphism", "Encapsulation", "Inheritance", "Abstraction", "Inheritance"),
//            new Question("Java Fundamentals", "Which method is the main entry point of any standalone Java application?", "start()", "main()", "init()", "run()", "main()"),
//            
//            // Database Systems
//            new Question("Database Systems", "What does SQL stand for?", "Structured Query Language", "Sequential Query Language", "Simple Query Logic", "System Query Language", "Structured Query Language"),
//            new Question("Database Systems", "Which SQL clause is used to filter records in a SELECT query?", "GROUP BY", "WHERE", "ORDER BY", "HAVING", "WHERE"),
//            new Question("Database Systems", "Which SQL command is used to remove a table and all its data permanently?", "REMOVE TABLE", "DELETE TABLE", "DROP TABLE", "TRUNCATE TABLE", "DROP TABLE"),
//            new Question("Database Systems", "What type of key uniquely identifies each row in a database table?", "Foreign Key", "Primary Key", "Super Key", "Candidate Key", "Primary Key"),
//            new Question("Database Systems", "Which operator is used to search for a specified pattern in a column?", "LIKE", "MATCH", "SEARCH", "IN", "LIKE"),
//
//            // Web Development Essentials
//            new Question("Web Development Essentials", "What does HTML stand for?", "Hyper Text Markup Language", "High Tech Modern Language", "Hyper Transfer Main Language", "Home Tool Markup Language", "Hyper Text Markup Language"),
//            new Question("Web Development Essentials", "Which CSS property is used to change the background color of an element?", "color", "background-color", "bgcolor", "canvas-color", "background-color"),
//            new Question("Web Development Essentials", "Which JavaScript array method adds an element to the end of an array?", "push()", "pop()", "shift()", "append()", "push()"),
//            new Question("Web Development Essentials", "What is the default layout display mode of a <div> tag in HTML?", "inline", "block", "flex", "grid", "block"),
//            new Question("Web Development Essentials", "Which HTTP status code signifies \"200 OK\"?", "404", "500", "200", "301", "200"),
//
//            // General Science & Tech
//            new Question("General Science & Tech", "What is the chemical symbol for Gold?", "Au", "Ag", "Fe", "Pb", "Au"),
//            new Question("General Science & Tech", "Which planet in our solar system is known as the Red Planet?", "Earth", "Mars", "Jupiter", "Venus", "Mars"),
//            new Question("General Science & Tech", "What is the speed of light in vacuum approximately?", "300,000 km/s", "150,000 km/s", "1,000,000 km/s", "30,000 km/s", "300,000 km/s"),
//            new Question("General Science & Tech", "Which component is considered the brain of a computer?", "RAM", "Hard Drive", "CPU", "GPU", "CPU")
        };

        for (Question q : defaults) {
            boolean exists = false;
            for (Question existing : questions) {
                if (existing.getQuizTitle().equalsIgnoreCase(q.getQuizTitle()) &&
                    existing.getQuestionText().equalsIgnoreCase(q.getQuestionText())) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                questions.add(q);
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement("INSERT INTO questions (quiz_title, question_text, option_a, option_b, option_c, option_d, correct_option) VALUES (?,?,?,?,?,?,?)")) {
                    ps.setString(1, q.getQuizTitle());
                    ps.setString(2, q.getQuestionText());
                    ps.setString(3, q.getOptionA());
                    ps.setString(4, q.getOptionB());
                    ps.setString(5, q.getOptionC());
                    ps.setString(6, q.getOptionD());
                    ps.setString(7, q.getCorrectOption());
                    ps.executeUpdate();
                } catch (Exception ignored) {}
            }
        }
    }
    
    public static List<Question> getQuestionsForQuiz(String quizTitle) {
        loadQuestions();
        List<Question> result = new ArrayList<>();
        for (Question q : questions) {
            if (q.getQuizTitle().equalsIgnoreCase(quizTitle)) {
                result.add(q);
            }
        }
        return result;
    }

    public static boolean addQuestion(Question q) {
        String sql = "INSERT INTO questions (quiz_title, question_text, option_a, option_b, option_c, option_d, correct_option) VALUES (?,?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, q.getQuizTitle());
            ps.setString(2, q.getQuestionText());
            ps.setString(3, q.getOptionA());
            ps.setString(4, q.getOptionB());
            ps.setString(5, q.getOptionC());
            ps.setString(6, q.getOptionD());
            ps.setString(7, q.getCorrectOption());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("addQuestion error: " + e.getMessage());
        }
        questions.add(q);
        return true;
    }
    
    public static boolean deleteQuestion(Question q) {
        String sql = "DELETE FROM questions WHERE quiz_title=? AND question_text=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, q.getQuizTitle()); 
            ps.setString(2, q.getQuestionText());
            ps.executeUpdate();
            questions.remove(q);
            return true;
        } catch (SQLException e) { 
            System.err.println("deleteQuestion error: " + e.getMessage()); 
            questions.remove(q);
            return true; 
        }
    }
    
    public static void loadResults() {
        try (Connection con = DBConnection.getConnection();
             Statement  st  = con.createStatement();
             ResultSet  rs  = st.executeQuery("SELECT * FROM results ORDER BY attempt_date DESC")) {
            List<ResultRecord> dbResults = new ArrayList<>();
            while (rs.next()) {
                dbResults.add(new ResultRecord(
                        rs.getString("student_name"),
                        rs.getString("roll_no"),
                        rs.getString("quiz_name"),
                        rs.getString("score"),
                        rs.getString("percentage"),
                        rs.getString("grade")
                ));
            }
            if (!dbResults.isEmpty()) {
                results = dbResults;
            }
        } catch (SQLException e) {
            System.err.println("loadResults error: " + e.getMessage());
        }
        
        ensureSeedResults();
    }

    private static void ensureSeedResults() {
        ResultRecord[] defaults = new ResultRecord[]{
//            new ResultRecord("Alex Johnson", "STU-1001", "Java Fundamentals", "5/5", "100.0%", "A+"),
//            new ResultRecord("Sophia Smith", "STU-1002", "Database Systems", "4/5", "80.0%", "A"),
//            new ResultRecord("Michael Brown", "STU-1003", "Java Fundamentals", "4/5", "80.0%", "A"),
//            new ResultRecord("Emily Davis", "STU-1004", "Web Development Essentials", "3/5", "60.0%", "B")
        };
        for (ResultRecord r : defaults) {
            boolean exists = false;
            for (ResultRecord existing : results) {
                if (existing.getRollNo().equalsIgnoreCase(r.getRollNo()) &&
                    existing.getQuizName().equalsIgnoreCase(r.getQuizName())) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                results.add(r);
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement("INSERT INTO results (student_name, roll_no, quiz_name, score, percentage, grade) VALUES (?,?,?,?,?,?)")) {
                    ps.setString(1, r.getStudentName());
                    ps.setString(2, r.getRollNo());
                    ps.setString(3, r.getQuizName());
                    ps.setString(4, r.getScore());
                    ps.setString(5, r.getPercentage());
                    ps.setString(6, r.getGrade());
                    ps.executeUpdate();
                } catch (Exception ignored) {}
            }
        }
    }
    
    public static void saveResult(String studentName, String rollNo, String quizTitle, int score, int total) {
        double pct = total > 0 ? (score * 100.0 / total) : 0;
        String grade;
        if      (pct >= 90) grade = "A+";
        else if (pct >= 75) grade = "A";
        else if (pct >= 60) grade = "B";
        else if (pct >= 40) grade = "C";
        else                grade = "F";

        String scoreStr = score + "/" + total;
        String pctStr   = String.format("%.1f%%", pct);

        String sql = "INSERT INTO results (student_name, roll_no, quiz_name, score, percentage, grade) VALUES (?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, studentName); 
            ps.setString(2, rollNo);
            ps.setString(3, quizTitle);   
            ps.setString(4, scoreStr);
            ps.setString(5, pctStr);      
            ps.setString(6, grade);
            ps.executeUpdate();
        } catch (SQLException e) { 
            System.err.println("saveResult error: " + e.getMessage()); 
        }

        results.add(0, new ResultRecord(studentName, rollNo, quizTitle, scoreStr, pctStr, grade));
    }
   
    public static class ResultRecord {
        private final String studentName, rollNo, quizName, score, percentage, grade;
        public ResultRecord(String studentName, String rollNo, String quizName,
                            String score, String percentage, String grade) {
            this.studentName = studentName; 
            this.rollNo = rollNo;
            this.quizName    = quizName;    
            this.score  = score;
            this.percentage  = percentage;  
            this.grade  = grade;
        }
        public String getStudentName() { return studentName; }
        public String getRollNo()      { return rollNo;      }
        public String getQuizName()    { return quizName;    }
        public String getScore()       { return score;       }
        public String getPercentage()  { return percentage;  }
        public String getGrade()       { return grade;       }
    }
}
