/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quiz_project;

import javafx.application.Application;

/**
 *
 * @author KSC67
 */
class HelloApplication {
    public static void main(String[] args) {
        Application.launch(App.class, args);
    } 
}
