package constants;

public class adminEmailPassword {
    public static String email = "admin@gmail.com";
    public static  String password = "123456";
}
